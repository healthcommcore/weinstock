Congratulations on your purchase of WysiwygPro 3!

Please see Install.pdf for installation instructions. 