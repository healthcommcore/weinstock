<?php
if (!defined('IN_WPRO')) exit;
$lang = array();
$lang['wproCore_bookmark'] = array();
$lang['wproCore_bookmark']['bookmarkName'] = 'Bookmark name:';
$lang['wproCore_bookmark']['existingBookmarks'] = 'Existing bookmarks:';
?>