<?php 
if (!defined('IN_WPRO')) exit;
$lang=array();
$lang['wproCore_specialCharacters'] = array();
$lang['wproCore_specialCharacters']['insert'] = 'Insert character code:';
$lang['wproCore_specialCharacters']['browserWarning'] = 'These characters are not supported by all Web Browsers.';
$lang['wproCore_specialCharacters']['Common'] = 'Common';
$lang['wproCore_specialCharacters']['Latin 1'] = 'Latin';
$lang['wproCore_specialCharacters']['C0 Controls and Basic Latin'] = 'C0 Controls and Basic Latin';
$lang['wproCore_specialCharacters']['Latin Extended-A'] = 'Latin Extended-A';
$lang['wproCore_specialCharacters']['Spacing Modifier Letters'] = 'Spacing Modifier Letters';
$lang['wproCore_specialCharacters']['General Punctuation'] = 'General Punctuation';
$lang['wproCore_specialCharacters']['Latin Extended-B'] = 'Latin Extended-B';
$lang['wproCore_specialCharacters']['Greek Symbols'] = 'Greek Symbols';
$lang['wproCore_specialCharacters']['Letter-like Symbols'] = 'Letter-like Symbols';
$lang['wproCore_specialCharacters']['Arrows'] = 'Arrows';
$lang['wproCore_specialCharacters']['Mathematical Operators'] = 'Mathematical Operators';
$lang['wproCore_specialCharacters']['Miscellaneous Technical'] = 'Miscellaneous Technical';
$lang['wproCore_specialCharacters']['Miscellaneous Symbols'] = 'Miscellaneous Symbols';

?>