<?php 
if (!defined('IN_WPRO')) exit;
$lang=array();
$lang['wproCore_find'] = array();
$lang['wproCore_find']['findNext'] = 'Find Next';
$lang['wproCore_find']['replace'] = 'Replace';
$lang['wproCore_find']['replaceAll'] = 'Replace All';
$lang['wproCore_find']['findWhat'] = 'Find what:';
$lang['wproCore_find']['replaceWith'] = 'Replace with:';
$lang['wproCore_find']['matchCase'] = 'Match case';
$lang['wproCore_find']['matchWholeWords'] = 'Match whole words only';
$lang['wproCore_find']['JSFinishedSearching'] = 'Finished searching the document.';
$lang['wproCore_find']['JSReplacements'] = '##num## replacements were made.';
?>