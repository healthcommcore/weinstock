<?php 
if (!defined('IN_WPRO')) exit;
$lang=array();
$lang['wproCore_emoticons'] = array();
$lang['wproCore_emoticons']['smile'] = 'Smile';
$lang['wproCore_emoticons']['embarrassed'] = 'Embarrassed';
$lang['wproCore_emoticons']['wink'] = 'Wink';
$lang['wproCore_emoticons']['star'] = 'Star';
$lang['wproCore_emoticons']['shocked'] = 'Shocked';
$lang['wproCore_emoticons']['dead'] = 'Dead';
$lang['wproCore_emoticons']['big_smile'] = 'Big smile';
$lang['wproCore_emoticons']['sleepy'] = 'Sleepy';
$lang['wproCore_emoticons']['confused'] = 'Confused';
$lang['wproCore_emoticons']['disapprove'] = 'Disapprove';
$lang['wproCore_emoticons']['unhappy'] = 'Unhappy';
$lang['wproCore_emoticons']['shocked'] = 'Shocked';
$lang['wproCore_emoticons']['approve'] = 'Approve';
$lang['wproCore_emoticons']['angry'] = 'Angry';
$lang['wproCore_emoticons']['evil_smile'] = 'Evil smile';
$lang['wproCore_emoticons']['shocked'] = 'Shocked';
$lang['wproCore_emoticons']['clown'] = 'Clown';
$lang['wproCore_emoticons']['cool'] = 'Cool';
?>