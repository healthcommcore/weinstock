<?php 
if (!defined('IN_WPRO')) exit;
$lang=array();
$lang['wproCore_list'] = array();
$lang['wproCore_list']['listType'] = 'List-type:';
$lang['wproCore_list']['bulleted'] = 'Bulleted';
$lang['wproCore_list']['disc'] = 'Disc';
$lang['wproCore_list']['circle'] = 'Circle';
$lang['wproCore_list']['square'] = 'Square';
$lang['wproCore_list']['numbered'] = 'Numbered';
$lang['wproCore_list']['decimal'] = 'Decimal';
$lang['wproCore_list']['lower-roman'] = 'Lower-roman';
$lang['wproCore_list']['upper-roman'] = 'Upper-roman';
$lang['wproCore_list']['lower-alpha'] = 'Lower-alpha';
$lang['wproCore_list']['upper-alpha'] = 'Upper-alpha';
$lang['wproCore_list']['startFrom'] = 'Start from:';
?>