<?php
if (!defined('IN_WPRO')) exit;
$DEFAULT_PLUGINS = array(

);
?>