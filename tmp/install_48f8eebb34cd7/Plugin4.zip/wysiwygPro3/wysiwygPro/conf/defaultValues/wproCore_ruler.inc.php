<?php
if (!defined('IN_WPRO')) exit;
$defaultValues = array();
$defaultValues['rulerAlign'] = '';
$defaultValues['rulerWidth'] = '';
$defaultValues['widthUnits'] = '';
$defaultValues['rulerHeight'] = '';
$defaultValues['rulerColor'] = '';
$defaultValues['style'] = '';
?>