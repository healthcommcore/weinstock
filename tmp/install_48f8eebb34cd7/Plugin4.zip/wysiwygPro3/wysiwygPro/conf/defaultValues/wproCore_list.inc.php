<?php
if (!defined('IN_WPRO')) exit;
$defaultValues = array();

$defaultValues['style'] = '';

?>