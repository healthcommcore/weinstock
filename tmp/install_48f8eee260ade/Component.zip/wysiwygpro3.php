<?php

include_once(JPATH_BASE.'/administrator/components/com_wysiwygpro3/admin.wysiwygpro3.php');

?>